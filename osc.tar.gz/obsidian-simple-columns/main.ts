import { App, Plugin, PluginSettingTab, Setting } from "obsidian"

// What action to take depending on the presence of column tags
enum ElementAction {
	Move, // Move the entire content to the next element and make the current one empty
	Render, // Break the element into columns and let them render
	Skip // Ignore this element because it's outside of column blocks
}

interface SimpleColumnsSettings {
	defaultColumnArrangement: string
}

const DEFAULT_SETTINGS: SimpleColumnsSettings = {
	defaultColumnArrangement: "ltr"
}

// Returns an HTML element string with every column as a div child
const getColumns = (html: string): string => html
	// Regex applicable for these patterns:
	// [col]<br>
	// <p>[col]</p>
	.split(/(\[col\]<br>|<p>\[col\]<\/p>)/)
	.flatMap(column => column.split("\n"))
	.map(column => {
		console.warn(column)
		return column
	})
	// Regex applicable for these patterns:
	// starts with <p>[begin]
	// starts with [col]
	// starts with [end]
	.filter(line => line && !/^(<p>\[begin\]|\[col\]|\[end\])/.test(line))
	.map(column => {
		console.warn(column)
		return column
	})
	.map(column => `<div class="column-child">${column}</div>`)
	.join("")
// TODO
// const getColumns = (html: string): string => {
// 	let tmpCol = html.split(/(\[col\]<br>|<p>\[col\]<\/p>)/).join("")
// 	let tmpEl = createDiv()
// 	tmpEl.innerHTML = tmpCol
// 	tmpEl.innerText = tmpEl.innerText
// 		.split("\n")
// 		.filter(line => !/^\[(begin|col|end)\]/.test(line))
// 		.join("\n")

// 	return tmpEl.innerHTML
// }

// Decides how treat the given element based on the presence of column tags
const getElementAction = (text: string): ElementAction => {
	console.error("action: text: ", text)
	let hasBeginTag = false, hasEndTag = false

	text.split("\n").forEach(line => {
		if (line.startsWith("[begin]")) {
			if (hasBeginTag) return ElementAction.Skip
			hasBeginTag = true
		}
		if (line.startsWith("[end]")) {
			if (hasEndTag) return ElementAction.Skip
			hasEndTag = true
		}
	})

	if (hasBeginTag) {
		if (hasEndTag) return ElementAction.Render
		return ElementAction.Move
	}

	return ElementAction.Skip
}

export default class SimpleColumnsPlugin extends Plugin {
	settings: SimpleColumnsSettings

	async onload() {
		await this.loadSettings()

		// This adds a settings tab so the user can configure various aspects of the plugin
		this.addSettingTab(new SimpleColumnsSettingsTab(this.app, this))

		/******** Main part of the logic starts here ********/

		// Variable to hold the content of a document element to paste into the next one
		// Useful for case ElementAction.Move (see below)
		let elAcc = ""

		this.registerMarkdownPostProcessor((el, ctx) => {
			el.innerHTML = (elAcc + el.innerHTML).replace("</p><p>", "<br>\n")
			elAcc = ""
			
			console.error("start: html: ", el.innerHTML)

			switch (getElementAction(el.innerText)) {
				case ElementAction.Move:
					console.error("move")
					elAcc = el.innerHTML
					el.innerHTML = ""
					break
				case ElementAction.Render:
					console.error("render")
					el.addClass("column-parent")
					el.innerHTML = getColumns(el.innerHTML)
					console.error("now: html: ", el.innerHTML)
					break
				case ElementAction.Skip:
					console.error("skip")
					break
			}
		})
	}

	onunload() { /* TODO how to force the block update after every Ctrl-E */ }

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData())
	}

	async saveSettings() {
		await this.saveData(this.settings)
	}
}

class SimpleColumnsSettingsTab extends PluginSettingTab {
	plugin: SimpleColumnsPlugin

	constructor(app: App, plugin: SimpleColumnsPlugin) {
		super(app, plugin)
		this.plugin = plugin
	}

	display(): void {
		const { containerEl } = this

		containerEl.empty()

		new Setting(containerEl)
			.setName("Default column arrangement")
			.setDesc("In what direction to arrange the column blocks")
			.addDropdown(dropdown => dropdown
				.addOption("ltr", "Left-to-right")
				.addOption("rtl", "Right-to-left")
				.setValue(this.plugin.settings.defaultColumnArrangement)
				.onChange(async value => {
					this.plugin.settings.defaultColumnArrangement = value
					await this.plugin.saveSettings()
				}))
	}
}
