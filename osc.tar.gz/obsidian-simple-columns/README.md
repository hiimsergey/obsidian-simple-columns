## TODO
- should4: (console.error of "action") the innerTextification of headings is problematic
- should5: it doesnt work because `getColumns` doesnt work for `<p>[col]</p>`
  - just search for `>[col]<` to ensure that col is not in the middle of plain text
- write README
- check whether its mobile-compatible
  - consider an update
- check for unnecessary spaces and breaks
  - check **Elements** under Dev Tools and `console.log` statements